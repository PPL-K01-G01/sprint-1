const express = require('express');
const app = express();
const port = 3000;
const userRoutes = require('./routes/user-routes');
const cookieParser = require('cookie-parser');

const db = require('./config/database');

app.use(express.static('public'));
app.use(express.json());
app.use(cookieParser());

db.authenticate()
    .then(() => {
        console.log('Database connected...');
        return db.sync({alter : true});
    })
    .catch(err => console.log('Error: ' + err));


app.use("/api", userRoutes);

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
